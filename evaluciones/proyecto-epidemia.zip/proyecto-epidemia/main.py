# Autor(es): Eric Cerna Lizama - Pablo Cofré 
import matplotlib.pyplot as plt

def lectura_datos (archivo):
    # Función que lee los datos de un archivo de texto y los almacena en una lista
    datos = []
    f = open("./" + archivo, "r")
    # Recorre las lineas del archivo y las almacena en la lista
    for linea in f:
        linea = datos.append(linea.rstrip("\n").split(","))
    return datos

def fuction_a(datos):
    # Función que cuenta la cantidad de casos de secuencia H5N1 por región
    contador_regiones = [
        ["Arica", 0],
        ["Tarapaca", 0],
        ["Antofagasta", 0],
        ["Atacama", 0],
        ["Coquimbo", 0],
        ["Valparaiso", 0],
        ["Metropolitana", 0],
        ["O Higgins", 0],
        ["Maule", 0],
        ["Nuble", 0],
        ["Bio Bio", 0],
        ["Araucania", 0],
        ["Los Rios", 0],
        ["Los Lagos", 0],
        ["Aysen", 0],
        ["Magallanes", 0]]
    
    # Recorre la lista de datos
    for dato in datos: 
        for region in contador_regiones:
            # Recorre la lista de regiones
            if dato[3] == region[0]:
                # Si la region del dato es igual a la region de la lista suma 1
                region[1] += 1
    return contador_regiones

def fuction_b(datos):
    # Función que cuenta la cantidad de casos negativos para el mes de abril del año 2023
    negativos_ab_23 = 0
    for dato in datos:
        if dato [2][3:] == "04-2023":
            if dato[9] == "Negativo":
                negativos_ab_23 += 1
    return negativos_ab_23

def fuction_c(datos):
    # Función que cuenta la cantidad de yuncos negativos
    yuncus_neg = 0
    for dato in datos:
        if dato[5] == "Yunco":
            if dato[9] == "Negativo":
                yuncus_neg += 1
    return yuncus_neg

def fuction_d(datos):
    # Función que cuenta la cantidad de liles negativos en junio del 2023
    lile_neg_jun23 = 0
    for dato in datos:
        if dato[5] == "Lile":
            if dato[2][3:] == "06-2023":
                if dato[9] == "Negativo":
                    lile_neg_jun23 += 1
    return lile_neg_jun23

def cantidad_casos_neg(datos):
    # Función que cuenta la cantidad de casos negativos
    casos_neg = [
        ["Gaviota", 0],
        ["Piquero", 0],
        ["Salteador", 0],
        ["Pelicano", 0],
        ["Guanay", 0]
    ]
    for dato in datos:
        # Recorre la lista de datos
        for caso in casos_neg:
            # Recorre la lista de casos_neg
            if dato[5] == caso[0]: 
                if dato[9] == "Negativo":
                    caso[1] += 1
    return casos_neg

def crear_grafico(etiquetas, datos):
    # Crear el gráfico de barras
    plt.bar(etiquetas, datos)
    # Agregar título y etiquetas al eje X e Y
    plt.title("Cantidad de casos negativos de algunas especies.")
    plt.xlabel("Aves")
    plt.ylabel("Cantidad de casos negativos")
    # Mostrar el gráfico
    plt.show()

def fuction_e(datos):
    lista_casos_neg = cantidad_casos_neg(datos)
    x = []
    y = []
    # Recorre la lista de casos negativos y los almacena en las listas x e y
    for caso in lista_casos_neg:
        x.append(caso[0])
        y.append(caso[1])
    crear_grafico(x, y)

def genera_salida(a, b, c, d):
    # Función que genera el archivo de salida
    f = open("resultadoS3.txt", "w")
    f.write("Autor(es): Eric Cerna Lizama - Pablo Cofré\n\n")
    f.write("Cantidad de casos de secuenciación por región:\n")
    
    for region in a:
        f.write("\t" + region[0] + ": " + str(region[1]) + "\n")
        
    f.write("\nCasos negativos mes abril del año 2023: " + str(b) + "\n")
    f.write("Casos negativo especie Yunco: " + str(c) + "\n")
    f.write('Incidencias 06/2023 del “Lile”: ' + str(d) + "\n")



if __name__ == "__main__":
    datos = lectura_datos("protocolo_vigilancia.txt") # Lectura de los datos del archivo
    a = fuction_a(datos)  # Casos de secuenciación por región de H5N1.
    b = fuction_b(datos)  # Casos negativos para el mes de abril del año 2023.
    c = fuction_c(datos)  # Casos negativos de la especie “Yunco”.
    d = fuction_d(datos)  # Casos negativos para la especie “Lile” para el mes de junio 2023.
    e = fuction_e(datos)  # Grafica la cantidad de casos negativos (incidencias)
    genera_salida(a, b, c, d)  # Genera el archivo de salida